# web-for-agents

Serve your site to AI agents as markdown. After your normal build, it converts every prerendered HTML page into clean markdown (main content only, no nav/footer/cookie banners) and writes `llms.txt` + `llms-full.txt`. Tiny request helpers let a server or middleware answer `Accept: text/markdown` on the same URL.

How agents find the markdown:

| Agent | Mechanism | Needs |
|---|---|---|
| Claude Code, Cursor, Copilot, OpenCode | `Accept: text/markdown` on the page URL | middleware (see Next.js below) |
| Codex CLI and link-followers | `<link rel="alternate" type="text/markdown">` / `Link` header | build (static) or middleware |
| Anyone guessing | `/page.md`, `/llms.txt` | build |

## Install

```bash
npm install github:<you>/web-for-agents
```

`prepare` compiles TypeScript on install.

## Static sites (Vite etc.)

```jsonc
// package.json
"build": "vite build && web-for-agents build dist --site https://example.com"
```

This writes `dist/<page>.md` next to each page, injects `<link rel="alternate" type="text/markdown">` into each HTML file, and writes `dist/llms.txt` and `dist/llms-full.txt`. Pages with almost no text (client-rendered SPAs) are skipped and listed in the output, because they need prerendering first.

## Next.js (app router, prerendered pages)

```jsonc
// package.json: convert the prerendered HTML into public/md (wiped and regenerated each build)
"build": "next build && web-for-agents build .next/server/app --site https://example.com --out public/md --base /md"
```

Add `/public/md/` to `.gitignore`. Pass `--no-llms` if you keep hand-written `public/llms.txt`.

```ts
// src/middleware.ts
import { NextResponse, type NextRequest } from 'next/server';
import { alternateLink, markdownRewrite } from 'web-for-agents';

export function middleware(request: NextRequest) {
  // "/docs/x.md" always, "/docs/x" when Accept prefers markdown → /md/docs/x.md
  const md = markdownRewrite(request.nextUrl, request.headers.get('accept'), '/md');
  const res = md ? NextResponse.rewrite(new URL(md, request.url)) : NextResponse.next();
  if (!md) res.headers.set('Link', alternateLink(request.nextUrl.pathname));
  res.headers.set('Vary', 'Accept');
  return res;
}

export const config = { matcher: ['/((?!_next/|api/|md/|.*\\.(?:ico|png|jpe?g|svg|webp|gif|txt|xml|json|js|css|woff2?)$).*)'] };
```

The `<link rel="alternate">` tag, which Codex reads from the HTML, comes from each page's metadata. The build then emits it:

```ts
import { mdPath } from 'web-for-agents';
export const metadata = { alternates: { canonical: '/docs', types: { 'text/markdown': mdPath('/docs') } } };
```

Next merges `alternates` shallowly, so a page that sets it must also set its own `canonical`. Leave `canonical` out of the root layout, or every page inherits the homepage's. A client component page (`'use client'`) can't export metadata; give its route a `layout.tsx` that does.

A page the build skipped has no `.md` file, so a markdown request for it gets a 404. Check the build output's `skipped` list.

Installing from git depends on `prepare`, which npm 11's install-script allowlist can block, and Vercel can't read a private repo. The dependable option is a prebuilt tarball committed to the site (`npm pack` → `vendor/`, then `"web-for-agents": "file:vendor/web-for-agents-0.1.0.tgz"`).

## API

- `web-for-agents`: edge-safe, no dependencies. Exports `prefersMarkdown(accept)`, `mdPath(pathname)`, `isPage(pathname)`, `markdownRewrite(url, accept, base?)` and `alternateLink(pathname)`.
- `web-for-agents/build`: `build({ dir, site, out?, base?, llms? })` returns `{ pages, skipped }`. Also `llmsTxt(pages, site)` and `routeOf(file)`.
- `web-for-agents/convert`: `convert(html, url)` returns `{ title, description, lang, markdown, textLength }`, plus `toMarkdownFile(converted, url, date)`.

## Develop

```bash
npm test
```

```bash
npm run try -- https://some.site/page
```

`npm test` runs the unit tests, including a build on a temporary folder. `npm run try` runs a live conversion check; run it with no URLs to use a sample set of platforms.
